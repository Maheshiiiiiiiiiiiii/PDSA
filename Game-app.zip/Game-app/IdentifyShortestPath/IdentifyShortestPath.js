const cities = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J"];
let graph = Array(10).fill().map(() => Array(10).fill(0));
let openCity;

function assignRandomDistances() {
    for (let i = 0; i < 10; i++) {
        for (let j = i + 1; j < 10; j++) {
            const distance = Math.floor(Math.random() * 46) + 5; // Random between 5 and 50
            graph[i][j] = distance;
            graph[j][i] = distance;
        }
    }
}

function createTabel() {
    const distanceTableDiv = document.getElementById('distanceTable');
    let tableHTML = "<table border='1'>";
    tableHTML += "<thead><tr><th>City</th>";
    for (let city of cities) {
        tableHTML += `<th><img src="img/${city}.PNG" alt="${city}" width="150" height="150"><div>${city}</div></th>`;
    }
    tableHTML += "</tr></thead>";
    tableHTML += "<tbody>";
    for (let i = 0; i < cities.length; i++) {
        tableHTML += `<tr><td><img src="img/${cities[i]}.PNG" alt="${cities[i]}" width="150" height="150"><div>${cities[i]}</div></td>`;
        for (let j = 0; j < cities.length; j++) {
            if (i === j) {
                tableHTML += '<td>-</td>';
            } else if (j > i) {
                tableHTML += `<td>${graph[i][j]} km</td>`;
            } else {
                tableHTML += '<td></td>';  // Empty cell
            }
        }
        tableHTML += "</tr>";
    }
    tableHTML += "</tbody></table>";
    distanceTableDiv.innerHTML = tableHTML;
}

function createAnswerInputs() {
    const answerSectionDiv = document.getElementById('answerSection');
    let inputHTML = '<div class="answer-inputs">';
    for (let i = 0; i < cities.length; i++) {
        if (i !== openCity) {
            inputHTML += `<div class="city-input"><img src="IdentifyShortestPathSource/${cities[i]}.jpg" alt="${cities[i]}" width="100" height="100"><input type="text" id="distanceTo${i}" placeholder="Distance to ${cities[i]}"></div>`;
        }
    }
    inputHTML += '</div>';
    answerSectionDiv.innerHTML = inputHTML;
}

function startGame() {
    assignRandomDistances();
    openCity = Math.floor(Math.random() * 10);
    const startCityImageElem = document.getElementById("startCityImg");
    startCityImageElem.src = `IdentifyShortestPathSource/${cities[openCity]}.jpg`;
    startCityImageElem.alt = cities[openCity];
    createTabel();
    createAnswerInputs();
    document.getElementById("gameArea").style.display = "block";
}

function dijkstra(source) {
    const n = graph.length;
    const visited = Array(n).fill(false);
    const dist = Array(n).fill(Number.POSITIVE_INFINITY);
    dist[source] = 0;
    for (let count = 0; count < n - 1; count++) {
        let u = -1;
        for (let i = 0; i < n; i++) {
            if (!visited[i] && (u === -1 || dist[i] < dist[u])) {
                u = i;
            }
        }
        visited[u] = true;
        for (let v = 0; v < n; v++) {
            if (!visited[v] && graph[u][v] && dist[u] !== Number.POSITIVE_INFINITY && dist[u] + graph[u][v] < dist[v]) {
                dist[v] = dist[u] + graph[u][v];
            }
        }
    }
    return dist;
}

function bellmanFord(source) {
    const n = graph.length;
    const dist = Array(n).fill(Number.POSITIVE_INFINITY);
    dist[source] = 0;
    for (let i = 1; i < n; i++) {
        for (let u = 0; u < n; u++) {
            for (let v = 0; v < n; v++) {
                if (graph[u][v] && dist[u] + graph[u][v] < dist[v]) {
                    dist[v] = dist[u] + graph[u][v];
                }
            }
        }
    }
    for (let u = 0; u < n; u++) {
        for (let v = 0; v < n; v++) {
            if (graph[u][v] && dist[u] + graph[u][v] < dist[v]) {
                console.error("Graph contains a negative-weight cycle");
                return;
            }
        }
    }
    return dist;
}

function submitAnswers() {
    const dijkstraDistances = dijkstra(openCity);
    const bellmanFordDistances = bellmanFord(openCity);
    let correctCount = 0;
    let totalCount = cities.length - 1;
    for (let i = 0; i < cities.length; i++) {
        if (i !== openCity) {
            const userAnswer = parseInt(document.getElementById(`distanceTo${i}`).value, 10);
            if (userAnswer === dijkstraDistances[i] && userAnswer === bellmanFordDistances[i]) {
                correctCount++;
            }
        }
    }
    const resultDiv = document.getElementById("result");
    if (correctCount === totalCount) {
        resultDiv.textContent = "All answers are correct!";
    } else {
        let incorrectCount = totalCount - correctCount;
        resultDiv.textContent = `${correctCount} cities are correct. ${incorrectCount} cities left to answer correctly.`;
    }
}

window.onload = startGame;
